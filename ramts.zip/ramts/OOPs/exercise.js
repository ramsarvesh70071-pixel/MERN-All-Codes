"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var promptSync = require("prompt-sync");
// 1.
// ----------------------------------------------
// class Addition {
//     a ;
//     b ;
//     sum :number;
//     initData() {
//         let prompt = promptSync();
//         this.a = prompt("Enter first Number : ");
//         this.b = prompt("Enter second number : ");
//     }
//     addData() {
//         this.sum = (parseInt(this.a) + parseInt(this.b));
//     }
//     printData() {
//         console.log(`Sum is: ${this.sum}`);
//     }
// }
// let add = new Addition();
// add.initData();
// add.addData();
// add.printData();
// =============================================================
// 2.------
//  class Multiplication {
//     a :number;
//     b : number;
//     product : number;
//     initData(x, y) {
//         this.a = x;
//         this.b = y;
//     }
//     multiplyData() {
//         this.product = this.a * this.b;
//     }
//     printData() {
//         console.log(`Multiplication is: ${this.product}`);
//     }
// }
// let multi = new Multiplication();
// multi.initData(20, 40);
// multi.multiplyData();
// multi.printData();
// // =======================================================
// // 3.--------
// class PosiNega {
//     a : number;
//     initData(x) {
//         this.a = x;
//     }
//     TestData() {
//         if (this.a < 0) {
//             console.log(`Number is Negative (${this.a})`);
//         } else if (this.a > 0) {
//             console.log(`Number is Positive (${this.a})`);
//         } else {
//             console.log(`Number is zero`);
//         }
//     }
// }
// let test1 = new PosiNega();
// test1.initData(20);
// test1.TestData();
// =======================================================
// 4.
// class EvenOdd {
//     num;
//     initData(x) {
//         this.num = x;
//     }
//     TestData() {
//         if (this.num % 2 == 0) {
//             console.log(`Number is even!`);
//         } else {
//             console.log(`Number is Odd`);
//         }
//     }
// }
// let test2 = new EvenOdd();
// test2.initData(13);
// test2.TestData();
// ============================================================
// 5.------
// class Maximum2{
//     a: number;
//     b: number;
//     initData(x,y){
//         this.a = x;
//         this.b = y;
//     }
//     cal_max(){
//         if(this.a>this.b){
//             console.log(`Maximum: ${this.a}`);
//         }
//         else{
//             console.log(`Maximum : ${this.b}`);
//         }
//     }
// }
// let max = new Maximum2();
// max.initData(12,15.6);
// max.cal_max();
// =====================================================================
// 6.------
// class Maximum3{
//     a: number;
//     b: number;
//     c: number;
//      initData(x,y,z){
//         this.a = x;
//         this.b = y;
//         this.c = z;
//     }
//     testMax(){
//         if(this.a>=this.b && this.a>=this.c){
//             console.log(`Maximum is : ${this.a}`);
//         }
//         else if(this.b>=this.a && this.b>=this.c){
//             console.log(`Maximum is : ${this.b}`);
//         }
//         else{
//             console.log(`Maximum is : ${this.c}`);
//         }
//     }
//     let max3 = new Maximum3();
//     max3.initData(12.5,1000,200);
//     max3.testMax();
// ===============================================================================
// 7.---
// class sumN{
//     n: number;
//     i: number
//     sum: number = 0;
//     initData(){
//         let prompt = promptSync();
//          this.n = prompt("Enter number: ");
//     }
//     sumCalculateN(){
//         for(this.i = 1; this.i<=this.n; this.i++){
//             this.sum = this.sum+this.i;
//         }
//         console.log(`Sum of first ${this.n} number is :  ${this.sum}`);
//     }
// }
// let sum_obj = new sumN();
// sum_obj.initData();
// sum_obj.sumCalculateN();
// ==========================================================================================
// 8.---
var prompt = promptSync();
var sum = /** @class */ (function () {
    function sum() {
        this.sum = 0;
    }
    sum.prototype.initData = function () {
        this.n = parseInt(prompt("Enter how many numbers you want to add: "));
    };
    sum.prototype.Cal_Data = function () {
        var Number = [this.n];
        console.log("Enter ".concat(this.n, " numbers :"));
        for (var i = 0; i < this.n; i++) {
            // for new input each time
            var num = parseInt(prompt("Number ".concat(i + 1, " :")));
            Number.push(num); // for add numbers
            this.sum = this.sum + num;
        }
        console.log("Sum of given ".concat(this.n, " number is : ").concat(this.sum));
    };
    return sum;
}());
var nSum = new sum();
nSum.initData();
nSum.Cal_Data();
