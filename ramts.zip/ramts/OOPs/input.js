"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var promptSync = require("prompt-sync");
var prompt = promptSync();
var num1 = prompt("Enter first number: ");
var num2 = prompt("Enter second number: ");
// 'preseInt' ko 'parseInt' karein aur PromiseRejectionEvent ko hatayein
var sum = parseInt(num1) + parseInt(num2);
console.log("The sum is: " + sum);
